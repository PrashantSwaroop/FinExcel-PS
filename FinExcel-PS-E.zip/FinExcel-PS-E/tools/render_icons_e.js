// Draws the ribbon PNGs listed by tools/gen_ribbon_e.py as Material Symbols Rounded glyphs
// (filled, weight 400) in the group colour, from the bundled font assets/ms-rounded.woff2. Needs Playwright.
const { chromium } = require('playwright'); const fs = require('fs'); const path = require('path');
const ROOT = path.join(__dirname, '..');
const need = JSON.parse(fs.readFileSync(path.join(__dirname, '.e-icons-needed.json')));
const font = fs.readFileSync(path.join(ROOT, 'assets', 'ms-rounded.woff2')).toString('base64');
const SIZES = [16, 20, 24, 32, 40, 48, 64, 80];
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  await p.setContent(`<style>@font-face{font-family:MS;src:url(data:font/woff2;base64,${font}) format('woff2');font-display:block}
    body{margin:0;background:transparent} .ms{font-family:MS;font-feature-settings:'liga';font-variation-settings:'FILL' 1;display:flex;align-items:center;justify-content:center;line-height:1;overflow:hidden}</style><div id="i" class="ms">home</div>`);
  await p.evaluate(() => document.fonts.ready);
  for (const [name, [glyph, color]] of Object.entries(need)) {
    for (const s of SIZES) {
      await p.setViewportSize({ width: s, height: s });
      await p.evaluate(([g, c, s]) => { const i = document.getElementById('i'); i.textContent = g; i.style.cssText = `width:${s}px;height:${s}px;font-size:${s}px;color:${c}`; }, [glyph, color, s]);
      await p.locator('#i').screenshot({ path: path.join(ROOT, 'assets', `${name}-${s}.png`), omitBackground: true });
    }
  }
  await b.close(); console.log(Object.keys(need).length * SIZES.length + ' icons drawn');
})();
