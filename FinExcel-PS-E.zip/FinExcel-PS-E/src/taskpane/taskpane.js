/*
 * FinExcel-PS · Version E — task pane (prototype, front end only).
 *
 *   ia.json        everything the pane and ribbon show: areas, parts, tools, short codes, Tabular notes sections,
 *                  and the Ribbon E spec. manifest.xml is generated from it (tools/gen_ribbon_e.py).
 *   Navigation     the I.5 cascade: a tab in the header opens the areas strip; an area drops its parts menu;
 *                  a part with tools drops its tools menu, each level with the tile it came from.
 *   Search         J.4.1 / J.4.2: one bar for tools, pages and sections (rail tile, "/" key, docked bar or the
 *                  ribbon's Book › Command). Hide/Unhide are one card each with a target and This sheet / All sheets.
 *   Excel          only hide/unhide/group rows, columns and sheets really change the workbook; everything else is
 *                  a prototype screen or a toast. There is no backend.
 */

/* global document, Excel, Office, navigator, console, setTimeout, clearTimeout, window */

import IA from "../ia.json";

const VERSION = "E";

/* ===================================================================
   STATE
   =================================================================== */
const AREAS = IA.areas;
const S = {
  area: "dm",
  part: "tabular-notes",
  drawer: "rest", // rest | hover | open
  drawerArea: "dm", // area being browsed inside the open drawer
  cPick1: null, // area picked in the first column
  cPick2: null, // part (with tools) picked in the second column
  dTool: null, // "partId|index" of the tool open in the pane
  cmd: null, // Search: { q, sel, verb, target, open, all, flash }
  cmdRecent: null, // Search: tool ids, most recent first
  railAsk: null, // { key, verb, k, all } - a Formatting tool asking its question in the menu
  markGroup: null, // Tabular notes section you landed on from Search
  lastTool: null, // "partId|index" of the last tool run from the drawer
  query: "",
  expanded: { 0: true },
  selected: "0-0",
  checks: {}, // "g-i" -> {note:bool, app:bool}
  toast: null,
  log: [],
  copyText: null,
};

const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const areaOf = (id) => AREAS.find((a) => a.id === id);
/* The Book screen (rail Book tile and the ribbon's Book group). It sits outside the areas. */
const BOOK_PART = { id: "book", name: IA.entity.name, short: "Book", menu: false, items: [], paneIcon: '<path d="M12 6C10 4.5 7 4 4 4.3v13.5c3-.3 6 .2 8 1.7 2-1.5 5-2 8-1.7V4.3C17 4 14 4.5 12 6zM12 6v13.5"></path>' };
const partOf = (pid) => {
  if (pid === "book" && IA.ribbon) return { area: { ...AREAS.find((a) => a.id === S.area), name: "Book" }, part: BOOK_PART };
  for (const a of AREAS) { const p = a.parts.find((x) => x.id === pid); if (p) return { area: a, part: p }; }
  return null;
};
const log = (action) => S.log.push({ time: new Date().toISOString(), version: VERSION, area: areaOf(S.area).name, part: partOf(S.part).part.name, drawer: S.drawer, action });

/* ===================================================================
   ICONS
   =================================================================== */
const ico16 = (d, size = 16, sw = 1.1) => `<svg width="${size}" height="${size}" viewBox="0 0 16 16" stroke-width="${sw}" aria-hidden="true"><path d="${d}"></path></svg>`;
const ico24 = (inner, size = 16, sw = 1.8) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" stroke-width="${sw}" aria-hidden="true">${inner}</svg>`;
const I = {
  down: (s = 16) => ico24('<path d="M6 9l6 6 6-6"></path>', s, 2),
  right: (s = 16) => ico24('<path d="M9 6l6 6-6 6"></path>', s, 2),
  filter: () => ico24('<path d="M4 5h16l-6 7v6l-4 2v-8z"></path>', 16),
  search: (s = 16) => ico24('<circle cx="11" cy="11" r="6"></circle><path d="M20 20l-4-4"></path>', s),
  table: () => ico24('<rect x="4" y="5" width="16" height="14" rx="1"></rect><path d="M4 10h16M10 10v9"></path>', 13),
  check: () => ico24('<path d="M5 12l5 5 9-10"></path>', 12, 3),
  lock: () => ico24('<path d="M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3"></path>', 12, 2.2),
  book: () => ico24('<path d="M12 6C10 4.5 7 4 4 4.3v13.5c3-.3 6 .2 8 1.7 2-1.5 5-2 8-1.7V4.3C17 4 14 4.5 12 6zM12 6v13.5"></path>', 16),
  target: () => ico24('<circle cx="12" cy="12" r="7"></circle><path d="M12 2v4M12 18v4M2 12h4M18 12h4"></path>', 16),
};
/* Pane icon for an area or part: the Pane 2 icon if the design has one, else the ribbon icon. */
const paneIco = (x, size = 16) => (x.paneIcon ? ico24(x.paneIcon, size) : ico24(`<g transform="scale(1.5)"><path d="${x.icon}" stroke-width="1.2"></path></g>`, size));
const paneParts = (a) => (a.paneOrder ? a.paneOrder.map((id) => a.parts.find((p) => p.id === id)) : a.parts);

/* ===================================================================
   TABULAR NOTES DATA
   =================================================================== */
function sectionRows(g, gi) {
  if (g.items.length) return g.items.map((it, ii) => ({ ...it, id: `${gi}-${ii}`, group: g.name }));
  return Array.from({ length: g.count }, (_, ii) => ({ id: `${gi}-${ii}`, n: "", name: "[Section name]", ph: true, group: g.name }));
}
const ALL_ROWS = IA.sections.flatMap((g, gi) => sectionRows(g, gi));
const rowById = (id) => ALL_ROWS.find((r) => r.id === id);
const checksOf = (id) => S.checks[id] || (S.checks[id] = { note: true, app: true });
const matches = (r, q) => !q || [r.name, r.code, r.range, r.group].some((v) => v && v.toLowerCase().includes(q));

/* ===================================================================
   EXCEL
   =================================================================== */
async function selectSection(r) {
  if (!r || (!r.code && !r.range)) return;
  try {
    await Excel.run(async (ctx) => {
      const nm = ctx.workbook.names.getItemOrNullObject(r.code || "");
      await ctx.sync();
      const rng = nm.isNullObject ? ctx.workbook.worksheets.getActiveWorksheet().getRange(r.range) : nm.getRange();
      rng.select();
      await ctx.sync();
    });
  } catch (e) { console.error(e); }
}
const colNum = (c) => c.split("").reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0);
const cellOf = (a) => { const m = /^\$?([A-Z]+)\$?(\d+)$/.exec(a); return m ? { c: colNum(m[1]), r: +m[2] } : null; };
async function findFromSelection() {
  const addr = await Excel.run(async (ctx) => { const r = ctx.workbook.getSelectedRange(); r.load("address"); await ctx.sync(); return r.address; });
  const first = cellOf(addr.split("!").pop().split(":")[0]);
  const hit = first && ALL_ROWS.find((r) => {
    if (!r.range) return false;
    const [a, b] = r.range.split(":").map(cellOf);
    return first.c >= a.c && first.c <= b.c && first.r >= a.r && first.r <= b.r;
  });
  return { addr: addr.split("!").pop(), hit };
}

/* ===================================================================
   RENDER
   =================================================================== */

/* ---------- Cascade menu (I.5 on H.2): menus keep their labels; opens with your area's parts already showing ---------- */
const GREYS = IA.greys || { color: "#6E6E6E", dark: "#3C3C3C", tint: "#EEEEEE" };
const colourOf = (areaId) => { const a = AREAS.find((x) => x.id === areaId); return a && a.color ? a : GREYS; };
const dIco = (inner, size, sw, colour) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" stroke-width="${sw}" style="stroke:${colour}" aria-hidden="true">${inner}</svg>`;
/* I.5: Material Symbols Rounded icons (filled, 400), bundled in assets/ms-rounded.woff2. */
const msI = (name, size, colour, extra = "") => `<span class="ms" aria-hidden="true" style="width:${size}px;height:${size}px;font-size:${size}px;line-height:${size}px;color:${colour};${extra}">${esc(name)}</span>`;
if (IA.nav === "cascade" && !document.getElementById("ms-font")) { // bundled (assets/ms-rounded.woff2, Apache 2.0) so it works offline
  const st = document.createElement("style"); st.id = "ms-font";
  st.textContent = `@font-face { font-family: 'Material Symbols Rounded'; font-style: normal; font-weight: 400; font-display: block; src: url("assets/ms-rounded.woff2") format("woff2"); }`;
  document.head.appendChild(st);
}
/* one tile: state "cur" / "picked" (tint, bold, colour), "on" (colour icon), "off" (pale grey, still clickable) */
function dTile(act, arg, item, c, state, chevron, extra = "") {
  const marked = state === "cur" || state === "picked", off = state === "off";
  const ic = off ? "#8A8A8A" : c.color;
  return `<button class="d-tile ${state}" data-act="${act}" data-arg="${esc(arg)}" aria-label="${esc(item.name)}" ${extra} data-log="${esc("Cascade: " + item.name)}"
    style="background:${marked ? c.tint : "transparent"};color:${off ? "#616161" : marked ? c.dark : "#3C3C3C"};font-weight:${marked ? 700 : 400}">
    ${chevron ? msI("chevron_right", 12, ic, "position:absolute;top:4px;right:2px") : ""}${msI(item.ms, 20, ic)}<span class="d-lb">${esc(item.short)}</span></button>`;
}
/* The pointer is a rotated square, not an SVG: the pane's global svg stroke rule gave the old one a black outline,
   and a plain box-shadow renders the same in Excel's Safari/Edge webviews (CSS filter shadows don't). */
const D_ARROW = '<span class="d-arrow" aria-hidden="true"></span>';
function renderCascade() {
  if (S.drawer !== "open") return "";
  const p1 = S.cmd ? null : S.cPick1, p2 = S.cmd ? null : S.cPick2;
  const st1 = (k) => (S.cmd ? (k === "command" ? "picked" : "off") : p1 ? (k === p1 ? "picked" : "off") : k === "home" && S.part === "book" ? "cur" : "on");
  const topC = (t) => (t.k === "command" ? IA.command : { color: "#616161", dark: "#3C3C3C", tint: GREYS.tint });
  const col1 = `<nav class="d-col d-col1" data-k="areas" aria-label="Areas">
    ${IA.cascadeTop.map((t) => dTile("dTop", t.k, t, topC(t), st1(t.k), false, t.k === "command" ? "data-d-cmd" : "")).join("")}
    <span class="d-rule"></span>
    ${AREAS.map((a) => dTile("dArea", a.id, a, a, st1(a.id), false, a.id === p1 ? "data-d-anchor1" : "")).join("")}
  </nav>`;
  let col2 = "", col3 = "";
  if (p1) {
    const a = areaOf(p1);
    const st2 = (id) => (p2 ? (id === p2 ? "picked" : "off") : id === S.part ? "picked" : "on");
    col2 = `<section class="d-col d-col2" data-k="parts:${esc(p1)}" aria-label="${esc(a.name)} parts">${D_ARROW}<div class="d-list">
      ${paneParts(a).map((pt) => dTile("dPart", pt.id, pt, a, st2(pt.id), pt.menu && pt.items.length, pt.id === p2 ? "data-d-anchor2" : "")).join("")}
    </div></section>`;
    if (p2) {
      const pt = partOf(p2).part;
      col3 = `<section class="d-col d-col3" data-k="tools:${esc(p2)}" aria-label="${esc(pt.name)} tools">${D_ARROW}<div class="d-list">
        ${pt.items.map((t, i) => `${t.section ? `<div class="d-sect">${esc(t.section)}</div>` : ""}${railAskHtml(pt, t, i, a) || `<button class="d-row" data-act="dTool" data-arg="${pt.id}|${i}" data-log="${esc("Cascade: " + pt.name + " → " + t.name)}">${msI(t.ms, 20, a.color)}<span>${esc(t.name)}</span></button>`}`).join("")}
      </div></section>`;
    }
  }
  return `<div class="d-scrim" data-k="scrim" data-act="closeDrawer"></div>${col1}${col2}${col3}${S.cmd ? renderSearch() : ""}`;
}
/* I.5 "top-aligned": parts start level with the picked area; tools start level with the picked part
   (the first part's tools line up with the parts menu instead). Each menu stays inside the pane,
   and its little arrow keeps pointing at the tile it came from. */
function placeCascade() {
  const sh = document.querySelector(".shell"); if (!sh) return;
  const base = sh.getBoundingClientRect().top, H = sh.clientHeight;
  const c2 = document.querySelector(".d-col2"), c3 = document.querySelector(".d-col3");
  const place = (col, anchor, want) => {
    if (!col || !anchor) return;
    const r = anchor.getBoundingClientRect();
    const top = Math.max(0, Math.min(want, H - 8 - col.offsetHeight));
    col.style.top = top + "px";
    const arrow = col.querySelector(".d-arrow");
    if (arrow) arrow.style.top = Math.max(6, Math.min(r.top - base + r.height / 2 - top - 5, col.offsetHeight - 16)) + "px";
  };
  const a1 = document.querySelector("[data-d-anchor1]"), a2 = document.querySelector("[data-d-anchor2]");
  if (c2 && a1) place(c2, a1, a1.getBoundingClientRect().top - base);
  if (c3 && a2) {
    // stays at 164 (I.5) while there's at least 176px for it, long names wrapping to two lines;
    // in a narrower pane it slides left over the parts menu's edge rather than squeezing further
    const W = sh.clientWidth;
    c3.style.maxWidth = "240px";
    const left = Math.max(128, Math.min(164, W - 8 - Math.min(c3.offsetWidth, 176)));
    c3.style.left = left + "px";
    c3.style.maxWidth = Math.min(240, W - 8 - left) + "px";
    const first = c2.querySelector(".d-tile") === a2;
    place(c3, a2, first ? parseFloat(c2.style.top) - 1 : a2.getBoundingClientRect().top - base);
  }
  const cm = document.querySelector(".d-cmd"), ac = document.querySelector("[data-d-cmd]");
  if (cm && ac) place(cm, ac, ac.getBoundingClientRect().top - base);
  // short panes: the areas strip scrolls, and the menus follow the tile they came from
  const c1 = document.querySelector(".d-col1");
  if (c1 && !c1.dataset.bound) { c1.dataset.bound = "1"; c1.addEventListener("scroll", placeCascade, { passive: true }); }
}
window.addEventListener("resize", () => { if (IA.nav === "cascade" && S.drawer === "open") placeCascade(); });
/* Tool row on a part screen: area-coloured icon. */
function dToolRow(p, it, i) {
  const a = colourOf(partOf(p.id).area.id);
  const ic = it.ms ? msI(it.ms, 16, it.locked ? "#A0A0A0" : a.color) : dIco(`<path d="${it.icon24}"></path>`, 16, 2, it.locked ? "#A0A0A0" : a.color);
  return `<button class="${it.legacy ? "legacy" : ""} ${it.locked ? "d-locked" : ""}" data-act="dTool" data-arg="${p.id}|${i}" data-log="${esc("Tool: " + it.name)}">${ic}<span class="d-tname">${esc(it.name)}</span>${it.locked ? `<span class="d-lock">${I.lock()}</span>` : ""}</button>`;
}
/* H.2: Textual Notes keeps the product's existing list; shown here as a placeholder. */
function dTextualScreen() {
  return `<div class="part">
    <label class="d-search">${I.search()}<input type="search" placeholder="Search textual notes" aria-label="Search textual notes"></label>
    <span class="lbl">[TEXTUAL NOTES LIST · AS IN THE PRODUCT TODAY]</span>
    <span class="d-ph" style="width:80%"></span><span class="d-ph" style="width:64%"></span><span class="d-ph" style="width:72%"></span>
  </div>`;
}
function dToolScreen(pt, i) {
  const t = pt.items[i], r = (IA.resultScreens || {})[`${pt.id}|${i}`], a = colourOf(partOf(pt.id).area.id);
  if (r) {
    return `<div class="part"><span class="lbl">${esc(r.cap)}</span><p class="d-text">${esc(r.text)}</p>
      <button class="d-cta" style="background:${a.dark}" data-act="bookItem" data-arg="${esc(r.button + ": prototype only, nothing changed")}" data-log="${esc("Tool: " + r.button)}">${esc(r.button)}</button></div>`;
  }
  return `<div class="part"><p>${esc(t.name)} isn't designed in Version ${VERSION} yet.</p></div>`;
}
function renderCascadeApp() {
  const { area, part } = partOf(S.part);
  const c = S.part === "book" ? GREYS : colourOf(area.id);
  const [tp, ti] = (S.dTool || "").split("|");
  const toolOpen = S.dTool && tp === part.id;
  const body = toolOpen ? dToolScreen(part, +ti) : part.id === "textual-notes" ? dTextualScreen() : SCREENS[part.id] ? SCREENS[part.id]() : genericPart(part);
  const title = toolOpen ? part.items[+ti].name : part.name;
  const active = document.activeElement && document.activeElement.id === "q";
  const book = S.part === "book";
  const tab = J41
    ? `<button class="d-tab e" data-act="openDrawer" aria-label="Open menu · current area ${esc(book ? "Book" : area.short)}" data-log="Cascade: tab" style="background:${book ? IA.command.color : c.color}">${msI(book ? "menu_book" : area.ms, 20, "#FFFFFF")}${msI("chevron_right", 12, "rgba(255,255,255,0.8)").replace('class="ms"', 'class="ms d-tchev"')}</button>`
    : `<button class="d-tab" data-act="openDrawer" aria-label="Open navigation" data-log="Cascade: tab">${dIco(part.paneIcon || "", 16, 2, c.color)}<span class="d-tabdot" style="background:${c.color}"></span></button>`;
  const kicker = J41 ? `<span style="color:${book ? IA.command.dark : c.dark}">${esc(book ? "Book" : area.short)}</span>` : `<span style="color:${c.dark}">${esc(book ? "Book" : area.name)}</span>`;
  document.getElementById("app").innerHTML = `
    <div class="shell nav-cascade ${J41 ? "nav-e" : ""}">
      <div class="main">
        <header class="d-ctx">
          ${tab}
          <span class="t">${kicker}<b>${esc(title)}</b></span>
        </header>
        ${J41 ? `<div class="search d-dock"><button class="d-dockbtn" data-act="openSearch" data-log="Search: docked bar">${msI("search", 16, "#6E6E6E")}<span>Search tools, pages, sections</span><span class="d-key">/</span></button></div>` : ""}
        ${body}
      </div>
      ${renderCascade()}
      ${S.toast ? `<div class="toast" role="status">${esc(S.toast)}</div>` : ""}
    </div>`;
  if (active) { const q = document.getElementById("q"); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }
  const fb = document.getElementById("fallback");
  if (fb) { fb.focus(); fb.select(); }
  placeCascade();
  if (J41) calmColumns();
  const cq = document.getElementById("cmdq");
  if (cq) { cq.focus(); cq.setSelectionRange(cq.value.length, cq.value.length); }
}


function renderList() {
  const q = S.query.trim().toLowerCase();
  let html = "";
  IA.sections.forEach((g, gi) => {
    const rows = sectionRows(g, gi).filter((r) => matches(r, q) || (q && g.name.toLowerCase().includes(q)));
    if (q && !rows.length) return;
    const open = q ? true : !!S.expanded[gi];
    html += `<button class="grp ${open ? "open" : ""} ${S.markGroup === gi ? "mark" : ""}" data-act="toggleGroup" data-arg="${gi}" aria-expanded="${open}" data-log="Group: ${esc(g.name)}">${open ? I.down() : I.right()}<span class="nm">${esc(g.name)}</span><span class="ct">${g.count}</span></button>`;
    if (open) {
      html += `<div class="kids">${rows.map((r) => {
        const c = checksOf(r.id);
        return `<div class="sec ${r.id === S.selected ? "sel" : ""}">
          <button class="go" data-act="select" data-arg="${r.id}" data-log="Section: ${esc(r.name)}">
            <span class="n">${esc(r.n)}</span>
            <span class="tx"><span class="nm ${r.ph ? "ph" : ""}">${esc(r.name)}</span>${r.code ? `<span class="code">${esc(r.code)} · ${esc(r.range)}</span>` : ""}</span>
          </button>
          <span class="cbs">
            <button class="cb" role="checkbox" aria-checked="${c.note}" aria-label="Note number applicable" title="Note number applicable" data-act="check" data-arg="${r.id}|note" data-log="Checkbox: Note number applicable">${c.note ? I.check() : ""}</button>
            <button class="cb" role="checkbox" aria-checked="${c.app}" aria-label="Applicable" title="Applicable" data-act="check" data-arg="${r.id}|app" data-log="Checkbox: Applicable">${c.app ? I.check() : ""}</button>
          </span></div>`;
      }).join("")}</div>`;
    }
  });
  return html || `<div class="empty">No sections match “${esc(S.query)}”.</div>`;
}

function renderFoot() {
  const r = rowById(S.selected);
  if (!r) return `<span class="where">Select a section</span>`;
  const gi = +r.id.split("-")[0], ii = +r.id.split("-")[1];
  const g = IA.sections[gi];
  const idx = ALL_ROWS.indexOf(r), next = ALL_ROWS[idx + 1];
  const nextLabel = next ? (next.ph ? next.group : next.name) : "";
  return `<span class="where">Section ${ii + 1} of ${g.count} · ${esc(g.name)}</span>
    <button class="next" data-act="next" ${next ? "" : "disabled"} data-log="Next">${next ? `<span>Next: ${esc(nextLabel)}</span>${I.right(13)}` : "<span>Last section</span>"}</button>`;
}

const SCREENS = {
  book: () => {
    const row = (title, sub, toastText) => `<button class="brow" data-act="bookItem" data-arg="${esc(toastText)}" data-log="${esc("Book: " + title)}"><b>${esc(title)}</b>${sub ? `<span>${esc(sub)}</span>` : ""}</button>`;
    return `<div class="list">
      <span class="cap">THIS BOOK</span>
      ${row("Book details", `${IA.entity.name} · Output Template · 7749`, "Book details: prototype only, nothing changed")}
      ${row("Change period", "Currently 2025 Mar YTD", "Change period: prototype only, nothing changed")}
      <span class="cap gap">OTHER BOOKS</span>
      ${row("Switch book…", "Opens the book list", "Switch book: prototype only, nothing changed")}
      <span class="cap gap">DATA</span>
      ${row("Refresh", "Pull the latest values for this book", "Refresh: prototype only, nothing changed")}
      ${row("Refresh List", "Reload the list of books and periods", "Refresh List: prototype only, nothing changed")}
      ${row("Upload input data", "Input templates for this period", "Upload input data: prototype only, nothing changed")}
      ${row("Upload template", "Replace the output template", "Upload template: prototype only, nothing changed")}
    </div>`;
  },
  "all-validation": () => {
    const v = IA.validation;
    return `
    <div class="search"><label>${I.search()}<input id="q" type="search" placeholder="Search sections, codes or sheets" aria-label="Search sections, codes or sheets"></label></div>
    <div class="list">
      <span class="cap">NEEDS ATTENTION · ${v.attention.length}</span>
      ${v.attention.map((c) => `<button class="check" data-act="checkItem" data-arg="${esc(c.title)}" data-log="${esc("Check: " + c.title)}"><b>${esc(c.title)}</b><span>${esc(c.status)}</span></button>`).join("")}
      <span class="cap gap">PASSED · ${v.passed.length}</span>
      <span class="passed">${v.passed.map(esc).join(" · ")}</span>
    </div>`;
  },

  "tabular-notes": () => `
    <div class="search" ${J41 ? "hidden" : ""}><label>${I.search()}<input id="q" type="search" placeholder="Search sections, codes or sheets" value="${esc(S.query)}" aria-label="Search sections, codes or sheets"></label></div>
    <div class="list" id="list">${renderList()}</div>
    <div class="foot" id="foot">${renderFoot()}</div>`,

  settings: () => `<div class="part">
      <p>Settings for this part haven't been designed yet.</p>
      <span class="lbl">USABILITY TEST LOG</span>
      <p>${S.log.length} actions recorded since the pane opened, including ribbon clicks.</p>
      <div class="row"><button class="btn ink" data-act="copylog">Copy log</button><button class="btn" data-act="clearlog">Clear</button></div>
      ${S.copyText ? `<textarea class="fallback" id="fallback" readonly>${esc(S.copyText)}</textarea><p>Copy didn't work here. The log is selected; press Ctrl+C.</p>` : ""}
    </div>`,
};
function genericPart(p) {
  const tools = p.placeholderMenu ? [] : p.items;
  return `<div class="part">
    <p>${esc(p.name)} isn't designed in Version ${VERSION} yet.${tools.length ? " Its tools from the ribbon dropdown are listed below." : ""}</p>
    ${tools.length ? `<span class="lbl">TOOLS</span><div class="tools">${tools.map((it, i) => it.icon24 || it.ms ? dToolRow(p, it, i) : `<button class="${it.legacy ? "legacy" : ""}" data-act="tool" data-arg="${p.id}|${i}" data-log="Tool: ${esc(it.name)}">${ico16(IA.itemIcons[it.icon], 16, 1.1).replace("<svg", `<svg style="color:${IA.itemColors[it.icon]}"`)}${esc(it.name)}</button>`).join("")}</div>` : ""}
  </div>`;
}

function render() {
  renderCascadeApp();
}
function renderListOnly() {
  const l = document.getElementById("list"), f = document.getElementById("foot");
  if (l) l.innerHTML = renderList();
  if (f) f.innerHTML = renderFoot();
}

let toastTimer;
function toast(msg) {
  S.toast = msg;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { S.toast = null; render(); }, 2600);
}

/* ===================================================================
   ACTIONS
   =================================================================== */
function goPart(pid) {
  const hit = partOf(pid);
  S.lastTool = null;
  S.area = hit.area.id; S.part = pid; S.drawerArea = hit.area.id;
  S.drawer = "rest"; S.copyText = null;
  S.cPick1 = null; S.cPick2 = null; S.dTool = null;
}
function selectRow(id) {
  S.selected = id;
  S.expanded[+id.split("-")[0]] = true;
  return selectSection(rowById(id));
}
const ACT = {
  openDrawer: () => {
    S.cmd = null;
    S.drawer = "open"; S.drawerArea = S.area; S.cPick1 = null; S.cPick2 = null;
    if (IA.nav === "cascade" && S.part !== "book") S.cPick1 = S.area; // H.2: open with your area's parts already showing
  },
  closeDrawer: () => { S.drawer = "rest"; S.cmd = null; },
  /* cascade menu */
  dTop: (k) => { if (k === "home") { S.cmd = null; goPart(IA.homePart || "book"); } else if (k === "command") { if (S.cmd) ACT.closeDrawer(); else openCommand(); } else ACT.focusSearch(); },
  dArea: (id) => { if (S.cmd) { S.cmd = null; S.cPick1 = null; } S.cPick1 = S.cPick1 === id ? null : id; S.cPick2 = null; },
    openSearch: () => openCommand(),
  sPick: (i) => searchGo(+i),
  sTarget: (k) => { S.cmd.open = S.cmd.target === k ? !S.cmd.open : true; S.cmd.target = k; S.cmd.sel = 0; },
  sAll: (v) => { S.cmd.all = v === "1"; },
  sRun: () => famRun(S.cmd.verb, S.cmd.target, S.cmd.all, "search"),
  sFlip: () => { const f = famOf(); if (f) { S.cmd.q = FAM[f.other].word; S.cmd.target = S.cmd.target || f.t; S.cmd.sel = 0; } },
  sRecent: (id) => searchRecent(id),
  railAll: (v) => { S.railAsk.all = v === "1"; },
  railRun: () => { const r = S.railAsk; famRun(r.verb, r.k, r.all, "rail"); },
      dPart: (pid) => {
    S.railAsk = null;
    const p = partOf(pid).part;
    if (p.menu && p.items.length) { S.cPick2 = S.cPick2 === pid ? null : pid; return; }
    goPart(pid);
  },
  dTool: (arg) => {
    const [pid, i] = arg.split("|"), t = partOf(pid).part.items[+i];
    if (t.locked) { toast(`${t.name}: super admin only. Locked for preparers.`); return; }
    if (J41 && RAIL_ASK[t.quick]) { // J.4.1 · 10: the same question as Search, under the row
      const [verb, k] = RAIL_ASK[t.quick];
      S.railAsk = S.railAsk && S.railAsk.key === arg ? null : { key: arg, verb, k, all: false };
      if (S.railAsk) loadSelInfo();
      return;
    }
    if (t.quick) { // I.5: Formatting's hide/show/group tools act on the selection, like the ribbon
      S.drawer = "rest";
      Excel.run(async (ctx) => { await QUICK[t.quick](ctx); await ctx.sync(); })
        .then(() => toast(`${t.name}: done`), (err) => toast(`${t.name}: ${err.message || err}`))
        .then(render);
      return;
    }
    goPart(pid); S.dTool = arg;
  },
                          checkItem: (title) => toast(`${title}: details aren't designed yet`),
  bookItem: (msg) => toast(msg),
  part: (pid) => goPart(pid),
  entity: () => toast("Switching entity isn't designed yet"),
  filter: () => toast("Filter isn't designed yet"),
  focusSearch: () => {
    if (S.part !== "tabular-notes") goPart("tabular-notes");
    S.drawer = "rest";
    setTimeout(() => { const q = document.getElementById("q"); if (q) q.focus(); }, 0);
  },
  findSel: async () => {
    S.drawer = "rest";
    if (S.part !== "tabular-notes") goPart("tabular-notes");
    const { addr, hit } = await findFromSelection();
    if (hit) { S.query = ""; await selectRow(hit.id); toast(`${addr} is in “${hit.name}”`); }
    else toast(`No section found for ${addr}`);
  },
  toggleGroup: (gi) => { S.markGroup = null; S.expanded[gi] = !S.expanded[gi]; },
  select: (id) => selectRow(id),
  check: (arg) => { const [id, k] = arg.split("|"); const c = checksOf(id); c[k] = !c[k]; },
  next: () => { const i = ALL_ROWS.findIndex((r) => r.id === S.selected); if (ALL_ROWS[i + 1]) return selectRow(ALL_ROWS[i + 1].id); return null; },
  tool: (arg) => { const [pid, i] = arg.split("|"); runTool(pid, +i); },
  copylog: () => {
    const text = JSON.stringify(S.log, null, 2);
    S.copyText = null;
    try { navigator.clipboard.writeText(text).then(() => { toast("Log copied"); render(); }, () => { S.copyText = text; render(); }); }
    catch (e) { S.copyText = text; }
  },
  clearlog: () => { S.log = []; S.copyText = null; },
};
function runTool(pid, i) {
  const p = partOf(pid).part, it = p.items[i];
  if (p.placeholderMenu) return;
  toast(`${it.name.replace(/…$/, "")}: prototype only, nothing changed`);
}

document.addEventListener("click", (e) => {
  const L = e.target.closest("[data-log]");
  if (L) log(L.getAttribute("data-log"));
  const b = e.target.closest("[data-act]");
  if (!b) return;
  if (b.disabled) return;
  Promise.resolve()
    .then(() => ACT[b.dataset.act] && ACT[b.dataset.act](b.dataset.arg))
    .catch((err) => { console.error(err); toast("Something went wrong: " + (err.message || err)); })
    .finally(render);
  render();
});
document.addEventListener("input", (e) => {
  if (e.target.id === "q") { S.query = e.target.value; renderListOnly(); }
  if (e.target.id === "cmdq" && S.cmd) { S.cmd.q = e.target.value; S.cmd.sel = J41 ? 0 : e.target.value.trim() ? 0 : -1; if (J41) { S.cmd.flash = null; S.cmd.target = null; S.cmd.all = undefined; S.cmd.open = undefined; refreshSearch(); return; } render(); }
});
document.addEventListener("keydown", (e) => {
  if (searchKey(e)) return;
  if (e.key === "Escape" && S.drawer !== "rest") { S.drawer = "rest"; S.cmd = null; render(); }
});
/* REST → HOVER → back to REST */
document.addEventListener("mouseover", (e) => {
  if (S.drawer === "rest" && e.target.closest(".edge")) { S.drawer = "hover"; render(); }
});
document.addEventListener("mouseout", (e) => {
  if (S.drawer !== "hover") return;
  const from = e.target.closest(".rail, .edge");
  const to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(".rail, .edge");
  if (from && !to) { S.drawer = "rest"; render(); }
});

const J41 = true; // J.4.1 / J.4.2 Search
/* ===================================================================
   VERSION E — command line ("J · Command line · recall any tool or place by typing")
   =================================================================== */
/* Every place and tool, with its full path and short code. */
const CMD_INDEX = (() => {
  if (!IA.command) return [];
  const out = [{ id: "place:book", kind: "place", name: IA.entity.name, short: "Book", code: "bk", ms: "home", c: { color: "#616161", dark: "#3C3C3C" }, path: ["Home"], pid: "book" }];
  for (const a of AREAS) for (const p of paneParts(a)) {
    out.push({ id: `place:${p.id}`, kind: "place", name: p.name, short: p.short, code: p.code, ms: p.ms, c: a, path: [a.crumb || a.short, p.short], pid: p.id });
    let sec = null;
    (p.items || []).forEach((t, i) => {
      if (t.section) sec = t.section;
      out.push({ id: `tool:${p.id}|${i}`, kind: "tool", name: t.name, code: t.code, ms: t.ms, c: a, path: [a.crumb || a.short, p.short, ...(p.pathSection && sec ? [sec] : [])], pid: p.id, i, quick: t.quick });
    });
  }
  return out;
})();
const cmdEntry = (id) => CMD_INDEX.find((x) => x.id === id);
/* Match by short code, by name, or by the starts of its words ("tex" → Table EXtraction). Returns bold ranges. */
function cmdMatch(name, code, q) {
  const n = name.toLowerCase();
  if (code === q) return { score: 0, marks: [] };
  const at = n.indexOf(q);
  if (at === 0) return { score: 1, marks: [[0, q.length]] };
  const starts = [...n.matchAll(/(^|[\s&·-])(\w)/g)].map((m) => m.index + m[1].length);
  let rest = q, from = 0; const marks = [];
  for (const st of starts) {
    if (st < from || !rest) continue;
    let k = 0; while (k < rest.length && n[st + k] === rest[k]) k++;
    if (k) { marks.push([st, st + k]); rest = rest.slice(k); from = st + k; }
  }
  if (!rest) return { score: 2, marks };
  if (at > 0 && starts.includes(at)) return { score: 2, marks: [[at, at + q.length]] };
  if (at > 0) return { score: 3, marks: [[at, at + q.length]] };
  return null;
}
const boldName = (name, marks) => { let h = "", last = 0; for (const [a, b] of marks) { h += esc(name.slice(last, a)) + `<b>${esc(name.slice(a, b))}</b>`; last = b; } return h + esc(name.slice(last)); };
const pathHtml = (x) => (x.path.length ? `<span class="d-cpath" style="color:${x.c.dark}">${x.path.map(esc).join(' <span class="d-csep">›</span> ')}</span>` : "");
const underline = (label, key) => { const i = label.toLowerCase().indexOf(key); return i < 0 ? esc(label) : esc(label.slice(0, i)) + `<u>${esc(label[i])}</u>` + esc(label.slice(i + 1)); };
function openCommand() {
  S.cmd = { q: "", sel: -1 }; S.drawer = "open"; S.cPick1 = null; S.cPick2 = null;
  if (J41) { S.cmd.sel = 0; S.railAsk = null; loadSelInfo(); }
}
function cmdRemember(id) { S.cmdRecent = [id, ...(S.cmdRecent || IA.command.recentSeed).filter((r) => r !== id)].slice(0, 3); }

/* ===================================================================
   VERSION E — J.4.1 Search: one bar for tools, pages and sections (Version E page, "J.4")
   =================================================================== */
/* Hide and Unhide are one tool each with a target (Rows / Columns / Sheets / Notes), picked from the selection. */
const FAM = {
  hide: { word: "hide", verb: "Hide", ms: "visibility_off", other: "unhide", tools: { r: "Hide rows", c: "Hide columns", s: "Hide sheets", n: "Hide notes" } },
  unhide: { word: "unhide", verb: "Unhide", ms: "visibility", other: "hide", tools: { r: "Unhide rows", c: "Unhide columns", s: "Show sheets", n: "Unhide notes" } },
};
const FAM_T = [{ k: "r", name: "Rows", ms: "table_rows" }, { k: "c", name: "Columns", ms: "view_column" }, { k: "s", name: "Sheets", ms: "tab" }, { k: "n", name: "Notes", ms: "sticky_note_2", legacy: true }];
const RAIL_ASK = { hideRows: ["hide", "r"], unhideRows: ["unhide", "r"], hideCols: ["hide", "c"], unhideCols: ["unhide", "c"] };
const FAM_MEMBERS = new Set(Object.values(FAM).flatMap((f) => Object.values(f.tools)));
const famEntry = (verb, k) => CMD_INDEX.find((x) => x.kind === "tool" && x.name === FAM[verb].tools[k]);
/* Selection facts the questions need: counts, sheet name, how many sheets, what is hidden. */
let SEL = null;
async function loadSelInfo() {
  try {
    SEL = await Excel.run(async (ctx) => {
      const r = ctx.workbook.getSelectedRange(); r.load("address,rowCount,columnCount");
      const ws = ctx.workbook.worksheets.getActiveWorksheet(); ws.load("name");
      const all = ctx.workbook.worksheets; all.load("items/name,items/visibility");
      await ctx.sync();
      const info = { rows: r.rowCount, cols: r.columnCount, entireCol: r.rowCount >= 1048576, entireRow: r.columnCount >= 16384, sheet: ws.name,
        sheets: all.items.filter((w) => w.visibility !== "VeryHidden").length, hiddenSheets: all.items.filter((w) => w.visibility === "Hidden").length, hiddenRows: 0, hiddenCols: 0 };
      try {
        const rs = info.entireCol ? [] : Array.from({ length: Math.min(r.rowCount, 300) }, (_, i) => { const x = r.getRow(i); x.load("rowHidden"); return x; });
        const cs = info.entireRow ? [] : Array.from({ length: Math.min(r.columnCount, 100) }, (_, i) => { const x = r.getColumn(i); x.load("columnHidden"); return x; });
        await ctx.sync();
        info.hiddenRows = rs.filter((x) => x.rowHidden).length; info.hiddenCols = cs.filter((x) => x.columnHidden).length;
      } catch (e) { /* counts stay 0 */ }
      return info;
    });
  } catch (e) { SEL = null; }
  render();
}
const nOf = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
/* What the picked target says and what its button does. */
function famFacts(verb, k) {
  const i = SEL || {}, hide = verb === "hide";
  if (k === "r") return { sub: hide ? `${nOf(i.rows || 0, "row")} selected` : `${i.hiddenRows || 0} hidden in selection`, btn: `${FAM[verb].verb} ${nOf(hide ? i.rows || 0 : i.hiddenRows || 0, "row")}`, scope: true };
  if (k === "c") return { sub: hide ? `${nOf(i.cols || 0, "column")} selected` : `${i.hiddenCols || 0} hidden in selection`, btn: `${FAM[verb].verb} ${nOf(hide ? i.cols || 0 : i.hiddenCols || 0, "column")}`, scope: true };
  if (k === "s") return hide ? { sub: i.sheet || "This sheet", btn: `Hide ${i.sheet || "this sheet"}` } : { sub: nOf(i.hiddenSheets || 0, "hidden sheet"), btn: `Show ${nOf(i.hiddenSheets || 0, "sheet")}` };
  return { sub: "Legacy", btn: `${FAM[verb].verb} notes` };
}
const defaultTarget = () => (SEL && SEL.entireCol ? "c" : "r");
/* "hide", "unhide"/"show", "hide col", a short code (hc, hca), or a member's own name. */
function famOf() {
  const q = S.cmd.q.trim().toLowerCase();
  if (!q) return null;
  const code = q.match(/^([hu])([rcsn])(a?)$/);
  if (code) return { verb: code[1] === "h" ? "hide" : "unhide", t: code[2], all: !!code[3], code: q, other: code[1] === "h" ? "unhide" : "hide" };
  const [w0, w1] = q.split(/\s+/);
  let verb = null;
  if (w0.length >= 2 && "hide".startsWith(w0)) verb = "hide";
  else if (w0.length >= 2 && ("unhide".startsWith(w0) || "show".startsWith(w0))) verb = "unhide";
  if (verb) {
    const t = w1 ? FAM_T.find((x) => x.name.toLowerCase().startsWith(w1)) : null;
    return { verb, t: t ? t.k : null, other: FAM[verb].other };
  }
  for (const v of ["hide", "unhide"]) for (const t of FAM_T) {
    const x = famEntry(v, t.k);
    if (x && cmdMatch(x.name, x.code, q)) return { verb: v, t: t.k, other: FAM[v].other };
  }
  return null;
}
function sectionHits(q) {
  return IA.sections.map((g, gi) => ({ g, gi, m: cmdMatch(g.name, null, q) })).filter((h) => h.m).slice(0, 4)
    .map((h) => ({ kind: "section", gi: h.gi, name: h.g.name, marks: h.m.marks, ms: "table_chart", c: areaOf("dm"), path: ["Notes", "Tabular", nOf(h.g.count, "table")] }));
}
/* Tools first, then pages, then sections (J.4.1 · 4). A short code goes straight to its tool (J.4.1 · 6).
   Tools also match by the page they live on ("rec" → Recon's tools), recent ones first. Pages show their short name. */
function searchResults() {
  const q = S.cmd.q.trim().toLowerCase();
  if (!q) return null;
  const fam = famOf();
  if (fam && fam.code) return { fam, tools: [], pages: [], sections: [] };
  const exact = CMD_INDEX.find((x) => x.code === q && !FAM_MEMBERS.has(x.name));
  if (exact) return { fam: null, tools: exact.kind === "tool" ? [{ ...exact, marks: [] }] : [], pages: exact.kind === "place" ? [{ ...exact, name: exact.short, marks: [] }] : [], sections: [] };
  const recent = S.cmdRecent || IA.command.recentSeed;
  const rank = (x) => { const i = recent.indexOf(x.id); return i < 0 ? 9 : i; };
  const named = [], byPage = [], pages = [];
  for (const x of CMD_INDEX) {
    if (x.kind === "tool" && FAM_MEMBERS.has(x.name)) continue;
    if (x.kind === "place") {
      const m = [cmdMatch(x.short, null, q), cmdMatch(x.name, null, q)].filter(Boolean).sort((a, b) => a.score - b.score)[0];
      if (m) pages.push({ ...x, name: cmdMatch(x.short, null, q) ? x.short : x.name, marks: m.marks, score: m.score });
      continue;
    }
    const m = cmdMatch(x.name, null, q);
    if (m) named.push({ ...x, marks: m.marks, score: m.score });
    else if (cmdMatch(x.path[1] || "", null, q)) byPage.push({ ...x, marks: [], score: 4 });
  }
  named.sort((a, b) => a.score - b.score || rank(a) - rank(b) || a.name.length - b.name.length);
  byPage.sort((a, b) => rank(a) - rank(b));
  pages.sort((a, b) => a.score - b.score || a.name.length - b.name.length);
  return { fam, tools: [...named, ...byPage.slice(0, 2)].slice(0, 4), pages: pages.slice(0, 4), sections: sectionHits(q) };
}
const flatResults = (r) => [...(r.fam ? [{ kind: "fam" }] : []), ...r.tools, ...r.pages, ...r.sections];
const goIcon = (c) => msI("arrow_forward", 16, c).replace('class="ms"', 'class="ms d-go"');
/* Keyboard pick: area tint and ↵. Mouse hover: an arrow slides in. No Run labels. */
function resultRow(x, i, sel) {
  const on = sel === i, c = x.c;
  return `<button class="d-crow ${on ? "on" : ""}" data-act="sPick" data-arg="${i}" data-log="${esc("Search: " + x.name)}" style="${on ? `background:${c.tint}` : ""}">${msI(x.ms, 16, c.color)}
    <span class="d-ctext"><span class="d-cname">${boldName(x.name, x.marks || [])}</span>${pathHtml(x)}</span>
    ${on ? `<span class="d-enter" style="color:${c.dark}">↵</span>` : goIcon(c.color)}</button>`;
}
function scopeBox(actAll, actRun, all, c, f) {
  const radio = (v, label, note) => `<button class="d-radio ${(v === "1") === all ? "on" : ""}" data-act="${actAll}" data-arg="${v}" data-log="${esc("Scope: " + label)}"><span class="d-rd" style="${(v === "1") === all ? `border:4px solid ${c.color}` : ""}"></span><span class="d-rl">${label}</span><span class="d-rn">${esc(note)}</span></button>`;
  return `<div class="d-scope" style="border-color:${c.color}">
    ${f.scope ? radio("0", "This sheet", (SEL && SEL.sheet) || "") + radio("1", "All sheets", String((SEL && SEL.sheets) || "")) : ""}
    <button class="d-do" data-act="${actRun}" data-log="${esc("Run: " + f.btn)}" style="background:${c.color}">${msI("keyboard_return", 16, "#FFFFFF")}<span>${esc(f.btn)}</span></button></div>`;
}
function famCard(r, on) {
  const F = FAM[r.fam.verb], c = areaOf("ed"), C = S.cmd;
  const k = C.target || r.fam.t || defaultTarget();
  C.verb = r.fam.verb; C.target = k; if (r.fam.all && C.all === undefined) C.all = true;
  if (C.open === undefined) C.open = !!r.fam.code; // a short code goes straight to the choice (J.4.2 · 6)
  const f = famFacts(F.word, k);
  return `<div class="d-fam" style="${on ? `background:${c.tint}` : ""}">
    <div class="d-cq">${msI(F.ms, 16, c.color)}<span class="d-ctext"><span class="d-cname"><b>${F.verb}</b></span><span class="d-cpath" style="color:${c.dark}">Edit <span class="d-csep">›</span> Formatting</span></span>${r.fam.code ? `<span class="d-code">${esc(r.fam.code)}</span>` : ""}</div>
    ${FAM_T.map((t) => (t.k === k
      ? `<button class="d-tg on ${C.open ? "open" : ""}" data-act="sTarget" data-arg="${t.k}" data-log="${esc("Target: " + t.name)}" style="border-color:${c.color}">${msI(t.ms, 16, c.color)}<span class="d-ctext"><span class="d-cname"><b>${underline(t.name, t.k)}</b></span><span class="d-cpath" style="color:${c.dark}">${esc(f.sub)}</span></span>${C.open ? "" : `<span class="d-enter" style="color:${c.dark}">↵</span>`}</button>${C.open ? scopeBox("sAll", "sRun", !!C.all, c, f) : ""}`
      : `<button class="d-tg" data-act="sTarget" data-arg="${t.k}" data-log="${esc("Target: " + t.name)}">${msI(t.ms, 16, c.color)}<span class="d-ctext"><span class="d-cname" style="font-weight:400">${underline(t.name, t.k)}${t.legacy ? ' <span class="d-csep">· legacy</span>' : ""}</span></span></button>`)).join("")}
  </div>
  <button class="d-flip" data-act="sFlip" data-log="Search: flip">${msI(FAM[F.other].ms, 16, c.color)}<span class="d-ctext"><span class="d-cname" style="font-weight:400"><b>${FAM[F.other].verb}</b> <span style="color:#6E6E6E">· similar</span></span></span><span class="d-key">Tab</span></button>`;
}
function renderSearch() {
  const C = S.cmd, res = searchResults();
  const input = `<label class="d-cin d-sin">${msI("search", 16, IA.command.color)}<input id="cmdq" type="text" autocomplete="off" spellcheck="false" value="${esc(C.q)}" placeholder="Tools, pages, sections" aria-label="Search tools, pages, sections"><span class="d-key">Esc</span></label>`;
  return `<section class="d-col d-cmd d-sp" data-k="search" aria-label="Search">${D_ARROW}<div class="d-list">${input}<div class="d-sres">${searchBody()}</div></div></section>`;
}
/* Everything under the bar; typing redraws only this. */
function searchBody() {
  const C = S.cmd, res = searchResults();
  let body = "";
  if (!res) {
    if (C.flash) body += `<div class="d-flash" style="color:${C.flash.ok ? "#2B6B3B" : "#9A3F12"}">${msI(C.flash.ok ? "check_circle" : "error", 16, C.flash.ok ? "#3E9A55" : "#C4314B")}<span>${esc(C.flash.text)}</span></div>`;
    body += `<div class="d-hint">Type a tool to run it, or a page or section to go there.</div>`;
  } else {
    const flat = flatResults(res);
    if (!flat.length) body += `<div class="d-none">${msI("search_off", 32, "#8A8A8A")}<b>Nothing matches “${esc(C.q.trim())}”</b><span>Try a shorter word, a sheet or note name, or a short code like hr.</span></div>`;
    let n = 0;
    const group = (title, items, rule) => (items.length ? `<div class="d-chead ${rule ? "rule" : ""}">${title}</div><div class="d-clist">${items.map((x) => resultRow(x, n++, C.sel)).join("")}</div>` : "");
    const hasTools = !!(res.fam || res.tools.length);
    if (hasTools) {
      body += `<div class="d-chead">Tools</div><div class="d-clist">`;
      if (res.fam) body += famCard(res, C.sel === n++);
      body += res.tools.map((x) => resultRow(x, n++, C.sel)).join("") + `</div>`;
    }
    body += group("Pages", res.pages, hasTools);
    body += group("Sections", res.sections, hasTools || res.pages.length);
    if (res.sections.length && !hasTools && !res.pages.length) body += `<div class="d-hint">Sections come from this book’s notes and sheets.</div>`;
  }
  const recent = (S.cmdRecent || IA.command.recentSeed).map(cmdEntry).filter(Boolean);
  body += `<div class="d-recent"><div class="d-chead">Recent tools</div>${recent.map((x) => `<button class="d-crow" data-act="sRecent" data-arg="${esc(x.id)}" data-log="${esc("Recent: " + x.name)}">${msI(x.ms, 16, x.c.color)}<span class="d-ctext"><span class="d-cname">${esc(x.name)}</span>${pathHtml(x)}</span>${goIcon(x.c.color)}</button>`).join("")}</div>`;
  return body;
}
function refreshSearch() {
  const box = document.querySelector(".d-sres");
  if (!box) { render(); return; }
  box.innerHTML = searchBody();
  placeCascade();
}
/* A menu column that was already on screen keeps still on a redraw; only new ones slide in. */
let SHOWN = new Set();
function calmColumns() {
  const now = new Set();
  document.querySelectorAll("[data-k]").forEach((el) => { const k = el.dataset.k; if (SHOWN.has(k)) el.classList.add("still"); now.add(k); });
  SHOWN = now;
}
/* Enter / click on a result: tools run, pages and sections take you there (J.4.1 · 9). */
function searchGo(i) {
  const res = searchResults(); if (!res) return;
  const x = flatResults(res)[i]; if (!x) return;
  if (x.kind === "fam") { if (!S.cmd.open) { S.cmd.open = true; return; } famRun(S.cmd.verb, S.cmd.target, !!S.cmd.all, "search"); return; }
  log(`Search → ${x.name}`);
  if (x.kind === "section") { goPart("tabular-notes"); S.query = ""; S.markGroup = x.gi; return; }
  if (x.kind === "tool") cmdRemember(x.id);
  goPart(x.pid);
  if (x.kind === "tool") S.dTool = `${x.pid}|${x.i}`;
}
function searchRecent(id) {
  const x = cmdEntry(id); if (!x) return;
  for (const verb of ["hide", "unhide"]) for (const t of FAM_T) if (FAM[verb].tools[t.k] === x.name) { S.cmd = { q: `${verb} ${t.name.toLowerCase()}`, sel: 0, target: t.k, all: false }; return; }
  cmdRemember(id); goPart(x.pid); if (x.kind === "tool") S.dTool = `${x.pid}|${x.i}`;
}
/* Runs Hide / Unhide on this sheet (or every sheet) and says what happened (J.4.1 · 8). */
async function famRun(verb, k, all, from) {
  const hide = verb === "hide", name = FAM[verb].tools[k], x = famEntry(verb, k);
  if (x) cmdRemember(x.id);
  log(`${from === "rail" ? "Menu" : "Search"} → ${name}${all ? " · all sheets" : ""}`);
  let text, ok = true;
  try {
    text = await Excel.run(async (ctx) => {
      const r = ctx.workbook.getSelectedRange(); r.load("address,rowCount,columnCount");
      const ws = ctx.workbook.worksheets.getActiveWorksheet(); ws.load("name");
      const book = ctx.workbook.worksheets; book.load("items/name,items/visibility");
      await ctx.sync();
      const visible = book.items.filter((w) => w.visibility !== "VeryHidden");
      const addr = r.address.split("!").pop(), where = all ? `on ${nOf(visible.length, "sheet")}` : "on this sheet";
      if (k === "r" || k === "c") {
        const n = k === "r" ? (hide ? r.rowCount : (SEL && SEL.hiddenRows) || r.rowCount) : (hide ? r.columnCount : (SEL && SEL.hiddenCols) || r.columnCount);
        for (const w of all ? visible : [ws]) { const g = w.getRange(addr); if (k === "r") g.getEntireRow().rowHidden = hide; else g.getEntireColumn().columnHidden = hide; }
        await ctx.sync();
        return `${nOf(n, k === "r" ? "row" : "column")} ${hide ? "hidden" : "shown"} ${where}`;
      }
      if (k === "s") {
        if (hide) { ws.visibility = Excel.SheetVisibility.hidden; await ctx.sync(); return `${ws.name} hidden`; }
        const hid = book.items.filter((w) => w.visibility === "Hidden"); hid.forEach((w) => { w.visibility = Excel.SheetVisibility.visible; }); await ctx.sync();
        return `${nOf(hid.length, "sheet")} shown`;
      }
      return `${name}: prototype only, nothing changed`;
    });
  } catch (err) { ok = false; text = `${name}: ${err.message || err}`; }
  if (from === "rail") { S.railAsk = null; S.drawer = "rest"; toast(text); }
  else {
    S.cmd = { q: "", sel: 0, flash: { text, ok } };
    setTimeout(() => { if (S.cmd && S.cmd.flash && S.cmd.flash.text === text) { S.cmd.flash = null; render(); } }, 3200);
  }
  loadSelInfo();
  render();
}
/* J.4.1 · 10: in the Formatting menu, Hide/Unhide rows or columns asks the same question under the row. */
function railAskHtml(pt, t, i, a) {
  const R = S.railAsk;
  if (!R || R.key !== `${pt.id}|${i}`) return "";
  const f = famFacts(R.verb, R.k);
  return `<button class="d-row d-ask" data-act="dTool" data-arg="${pt.id}|${i}" style="background:${a.tint}">${msI(t.ms, 20, a.color)}<span class="d-ctext"><span style="font-weight:700">${esc(t.name)}</span><span class="d-cpath" style="color:${a.dark}">${esc(f.sub)}</span></span></button>
    <div class="d-askbox" style="background:${a.tint}">${scopeBox("railAll", "railRun", !!R.all, a, f)}</div>`;
}
/* Keys: "/" opens Search; ↑↓ move; Enter runs or goes; Tab flips Hide ↔ Unhide; after "hide " the underlined letter picks a target, A = all sheets. */
function searchKey(e) {
  const typing = e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA");
  if (!S.cmd) {
    if (e.key === "/" && !typing) { e.preventDefault(); openCommand(); log("Search: / key"); render(); return true; }
    return false;
  }
  const C = S.cmd, res = searchResults(), flat = res ? flatResults(res) : [];
  if (e.key === "Escape") { e.preventDefault(); if (C.q) S.cmd = { q: "", sel: 0 }; else { S.cmd = null; S.drawer = "rest"; } render(); return true; }
  if (e.key === "Tab") { e.preventDefault(); if (res && res.fam) ACT.sFlip(); render(); return true; }
  if (e.key === "Enter" && res && res.fam && C.sel === 0 && !C.open) { e.preventDefault(); C.open = true; refreshSearch(); return true; }
  if (e.key === "ArrowDown") { e.preventDefault(); if (flat.length) C.sel = (C.sel + 1) % flat.length; refreshSearch(); return true; }
  if (e.key === "ArrowUp") { e.preventDefault(); if (flat.length) C.sel = C.sel <= 0 ? flat.length - 1 : C.sel - 1; refreshSearch(); return true; }
  if (e.key === "Enter") { e.preventDefault(); if (flat.length) searchGo(C.sel); render(); return true; }
  if (res && res.fam && /^[rcsna]$/i.test(e.key) && /^(hide|unhide|show)\s$/i.test(C.q) && !e.metaKey && !e.ctrlKey) {
    e.preventDefault();
    if (e.key.toLowerCase() === "a") C.all = !C.all; else { C.target = e.key.toLowerCase(); C.open = true; }
    C.sel = 0; render(); return true;
  }
  return false;
}

/* ===================================================================
   RIBBON — function names match manifest.xml (generated from ia.json)
   =================================================================== */
const RIBBON_FN = {}; // every ribbon handler by name
function assoc(name, fn) { RIBBON_FN[name] = fn; Office.actions.associate(name, fn); }
function bind(name, label, fn) {
  assoc(name, async (event) => {
    log("Ribbon: " + label);
    try {
      await Office.addin.showAsTaskpane();
      fn();
    } catch (err) { console.error(err); }
    render();
    event.completed();
  });
}
/* its own ribbon ("Ribbon: C" page), defined in versions/C/ia.json under "ribbon". */
const toolKey = (n) => String(n).replace(/^\d+\s*·\s*/, "").toLowerCase();
const findTool = (p, name) => p.items.findIndex((x) => toolKey(x.name) === toolKey(name));
function runTarget(t) {
  if (t.command) { openCommand(); return; }
  if (t.trace) { // "Run · trace current cell"
    goPart("trace-current-cell");
    Excel.run(async (ctx) => { const r = ctx.workbook.getSelectedRange(); r.load("address"); await ctx.sync(); return r.address; })
      .then((a) => toast(`Traced ${a.split("!").pop()}: prototype only`), () => toast("Trace: prototype only"))
      .then(render);
    return;
  }
  goPart(t.screen === "book" ? "book" : t.part);
  if (t.tool && IA.nav === "cascade") {
    const p = partOf(t.part).part, i = findTool(p, t.tool);
    if (i >= 0) { S.dTool = `${p.id}|${i}`; return; }
  }
  if (t.tool) {
    const p = partOf(t.part).part, i = p.items.findIndex((x) => x.name === t.tool);
    if (i >= 0) { S.lastTool = `${p.id}|${i}`; runTool(p.id, i); return; }
  }
  if (t.toast) toast(t.toast);
}
function registerRibbonFromSpec(R) {
  const f = (id) => (R.fnPrefix || "c_") + id.replace(/-/g, "_");
  for (const g of R.groups) {
    for (const c of g.controls) {
      if (c.type === "menu") c.items.forEach((it, i) => (it.target.quick ? bindQuick(`${f(c.id)}_${i}`, `${g.label} › ${c.label} › ${it.label}`, it.target.quick)
        : bind(`${f(c.id)}_${i}`, `${g.label} › ${c.label} › ${it.label}`, () => runTarget(it.target))));
      else if (c.target.quick) bindQuick(f(c.id), `${g.label} › ${c.label}`, c.target.quick);
      else bind(f(c.id), `${g.label} › ${c.label}`, () => runTarget(c.target));
    }
  }
}

/* Edit's hide/show buttons act on the selection directly. No pane, unless something goes wrong. */
const QUICK = {
  hideRows: async (ctx) => { ctx.workbook.getSelectedRange().getEntireRow().rowHidden = true; },
  unhideRows: async (ctx) => { ctx.workbook.getSelectedRange().getEntireRow().rowHidden = false; },
  hideCols: async (ctx) => { ctx.workbook.getSelectedRange().getEntireColumn().columnHidden = true; },
  unhideCols: async (ctx) => { ctx.workbook.getSelectedRange().getEntireColumn().columnHidden = false; },
  hideSheets: async (ctx) => { ctx.workbook.worksheets.getActiveWorksheet().visibility = Excel.SheetVisibility.hidden; },
  showSheets: async (ctx) => {
    const ws = ctx.workbook.worksheets; ws.load("items/visibility"); await ctx.sync();
    ws.items.forEach((w) => { if (w.visibility === Excel.SheetVisibility.hidden) w.visibility = Excel.SheetVisibility.visible; });
  },
  groupRows: async (ctx) => { ctx.workbook.getSelectedRange().getEntireRow().group(Excel.GroupOption.byRows); },
};
function bindQuick(name, label, key) {
  assoc(name, async (event) => {
    log("Ribbon: " + label);
    try {
      await Excel.run(async (ctx) => { await QUICK[key](ctx); await ctx.sync(); });
    } catch (err) {
      console.error(err);
      try { await Office.addin.showAsTaskpane(); } catch (e) { /* ignore */ }
      toast(`${label.split(" › ").pop()}: ${err.message || err}`);
      render();
    }
    event.completed();
  });
}


/* ===================================================================
   START
   =================================================================== */
Office.onReady((info) => {
  if (info.host !== Office.HostType.Excel) {
    document.getElementById("app").innerHTML = '<p class="boot">Open FinExcel-PS inside Excel to use it.</p>';
    return;
  }
  if (Office.actions) registerRibbonFromSpec(IA.ribbon);
  render();
});
