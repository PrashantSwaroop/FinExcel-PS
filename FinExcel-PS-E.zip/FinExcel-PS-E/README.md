# FinExcel-PS · Version E

A front-end prototype of the FinAlyzer Excel add-in: the **Version E** task pane and **Ribbon E**, running inside real Excel.
It exists so we can click through the design and run usability tests. **There is no backend**: apart from hiding/showing
rows, columns and sheets, every action shows a prototype screen or a short message.

Design source: the FinExcel-PS design canvas (https://claude.ai/artifact/MYtS9mNJcVeNhoKSLU5Crv)

| What | Canvas page · boards |
|---|---|
| Menu (areas → parts → tools) | Version: D · "I.5 · Every menu, top-aligned" (8 boards), opening behaviour from "H.2" |
| Search | Version E · "J.4" / J.4.1 (10 boards) as updated by J.4.2 (18 boards) |
| Ribbon | Ribbon E · "E.5 · Ribbon to Office add-in rules" |
| Type, spacing, radius, greys | Token |

## Run it

Needs Node 18+ and desktop Excel (Microsoft 365), Windows or Mac.

```
npm install
npm start          # builds, starts https://localhost:3000, opens Excel with the add-in loaded
npm stop           # when you're done
```

The first run installs a local HTTPS certificate (say yes to the prompt). The **FinExcel-PS · E** tab appears in the ribbon;
any of its buttons opens the pane. Keep the terminal open while you use Excel.

- Excel caches add-ins. If a ribbon change doesn't show, quit Excel, clear its cache and start again
  (Windows: `%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\`; Mac: `~/Library/Containers/com.microsoft.Excel/Data/Library/Caches/`
  and `.../Data/Library/Application Support/Microsoft/Office/16.0/Wef/`).
- Mac: if `npm start` fails with `EPERM` on Excel's folder, give Terminal Full Disk Access
  (System Settings › Privacy & Security), then reopen Terminal.
- Port 3000 must be free.

`npm run build` makes a production build in `dist/`; replace `https://localhost:3000/` with your host in `webpack.config.js`
(`urlProd`) and the manifest is rewritten on build.

## What's in here

```
manifest.xml              add-in manifest (generated: npm run manifest)
src/ia.json               all content: areas, parts, tools, short codes, Tabular notes sections, Ribbon E
src/taskpane/taskpane.js  the pane: menu, Search, screens, ribbon handlers, Excel actions
src/taskpane/taskpane.css styles (tokens at the top)
src/taskpane/taskpane.html
assets/                   ribbon icons e-<glyph>-<colour>-<size>.png, add-in icons, icon font
tools/gen_ribbon_e.py     ia.json → manifest.xml
tools/render_icons_e.js   draws the ribbon icons from the bundled icon font (needs Playwright)
```

The ribbon's buttons call functions in the pane (`e_<id>`, `e_<id>_<item>`), registered with `Office.actions.associate`.
The manifest uses a **shared runtime**, so the pane and the ribbon share one JavaScript context and the pane keeps its
state when closed.

To change wording, tools, codes or ribbon items, edit `src/ia.json`, then `npm run manifest` (and `npm run icons` if you
added a new icon). Icons are Material Symbols Rounded glyph names (filled, weight 400); the font is bundled in
`assets/ms-rounded.woff2` (Apache 2.0, see `assets/ms-rounded-LICENSE.txt`) so nothing loads from Google at runtime.

## How it behaves

**Closed.** A 36×56 tab at the left of the header, in the current area's colour with its icon (Book: slate). Hover grows it
to 42 px with a chevron. The header shows the area's short name and the page. Under it, a docked bar
"Search tools, pages, sections" with a `/` hint.

**Menu (I.5).** The tab opens a 72 px areas strip: Book · Search · Templates · Disclosure · Assurance · Formatting. It opens
with your current area picked and its parts showing. Picking an area tints it and greys the rest (still clickable); its parts
menu opens level with it, pointing at it. A part with tools (chevron) opens a tools menu level with that part, pushed up to
stay inside the pane. Menus never run off the pane: they move up and scroll inside; in a narrow pane the tools menu slides
over the parts menu's edge. Click outside or press Esc to close.

**Search (J.4.1 / J.4.2).** Opens from the Search tile, `/` anywhere in the pane, the docked bar, or the ribbon's
Book › Command. Clicking any other rail tile leaves it.
- Empty: the bar, a one-line hint, and the three most recent tools.
- Results come in three groups: **Tools**, **Pages**, **Sections** (Tabular notes groups). Each row shows where it lives
  ("Assurance › Recon"). ↑↓ moves, Enter runs or goes, Esc clears then closes. Tools also match by the page they're on.
- **Hide / Unhide** are one card each with a target: Rows, Columns, Sheets, Notes (legacy). The target is picked from the
  selection (whole columns → Columns). Typing "hide" only picks it; Enter or a click opens **This sheet / All sheets** and the
  button ("Hide 12 rows"). "unhide" or "show" opens Unhide; Tab flips between them; after "hide " the underlined letter picks
  a target and A toggles all sheets.
- Short codes jump straight to the open choice: `hr hc hs hn`, `ur uc us un`; add `a` for all sheets (`hca`).
  Other codes are in `ia.json` (`tn` Tabular notes, `xn` Textual notes, `co` Upload & compare ORT…).
- After a run: the bar clears, a green line says what happened and fades, the tool moves to the top of Recent.
- Pages and sections close the menu and take you there (a section is marked in the Tabular notes list).

**Formatting menu.** Hide/Unhide rows or columns ask the same This sheet / All sheets question under the row.

**Ribbon E.** Six groups: Book · Templates · Disclosure · Assurance · Edit · Info. Rows / Columns / Sheets items act on the
selection without opening the pane; everything else opens the pane on the right page or tool. Trace shows the traced cell.

**What really touches the workbook:** hide/unhide rows and columns (selection, this sheet or all sheets), hide the active
sheet, show hidden sheets, group the selected rows. Nothing else changes the file.

## Known limits

- Office add-ins can't choose big or small ribbon buttons, stack them, or space them: Excel decides from the window width.
  Ribbon E was designed within those rules.
- Only the Tabular notes list and the Upload & compare ORT screen are designed; other pages say "isn't designed yet" and
  list their tools. Textual notes shows a placeholder.
- Data (book, sections, counts) is sample data from `ia.json`.
- The pane keeps a usability-test click log in memory (`S.log`); it is not sent anywhere.
